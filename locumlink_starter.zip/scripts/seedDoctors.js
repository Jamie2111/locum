const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main(){
  await prisma.doctor.createMany({
    data: [
      { name:'Dr. Alice Kim', specialty:'Emergency Medicine', location:'Boston' },
      { name:'Dr. John Lee', specialty:'Internal Medicine', location:'New York' },
      { name:'Dr. Priya Patel', specialty:'Urgent Care', location:'Chicago' }
    ]
  });
  console.log('Seeded doctors');
}
main().catch(e=>{ console.error(e); process.exit(1); }).finally(()=>prisma.$disconnect());
