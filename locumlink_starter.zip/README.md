# LocumLink Starter (Demo)

This starter repo contains a minimal Next.js app with:
- Frontend pages: home + shifts listing
- API routes: /api/ingestJob, /api/matchDoctor
- Prisma schema for Shifts, Doctors, Applications
- Seed script to create demo doctors
- .env.example with placeholders

## Quickstart (local)

1. Install dependencies:
   ```
   npm install
   ```

2. Create `.env.local` and fill in:
   - DATABASE_URL (Supabase Postgres URL or local Postgres)
   - OPENAI_API_KEY

   You can use Supabase for the database (free tier).

3. Run Prisma migrate:
   ```
   npx prisma migrate dev --name init
   ```

4. Seed demo doctors:
   ```
   node scripts/seedDoctors.js
   ```

5. Run dev server:
   ```
   npm run dev
   ```

6. Visit http://localhost:3000

## Zapier / Apify

Deploy to Vercel and use the `/api/ingestJob` endpoint as the Zapier webhook URL. See project notes in the prompt conversation.

