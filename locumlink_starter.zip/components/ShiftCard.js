export default function ShiftCard({ shift }){
  return (
    <div className="card">
      <h3>{shift.title}</h3>
      <div style={{color:'#666'}}>{shift.location} • {shift.rate ? ('$'+shift.rate+'/hr') : 'Rate N/A'}</div>
      <p style={{marginTop:8}}>{shift.description}</p>
      <div style={{marginTop:8,color:'#333'}}>Applicants: {shift.applications?.length || 0}</div>
    </div>
  )
}
