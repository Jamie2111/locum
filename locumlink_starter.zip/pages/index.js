import Link from 'next/link'
export default function Home(){
  return (
    <main className="container">
      <h1>LocumLink — demo</h1>
      <p>Quick demo of locum ingestion + matching.</p>
      <div style={{display:'flex',gap:12,marginTop:18}}>
        <Link href='/shifts'><button className='btn'>View Shifts</button></Link>
      </div>
    </main>
  )
}
