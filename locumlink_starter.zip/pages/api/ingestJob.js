import prisma from '../../lib/prisma';

export default async function handler(req, res){
  if (req.method !== 'POST') return res.status(405).end();
  try {
    const body = req.body || {};
    const rawDescription = body.rawDescription || body.description || '';
    // Basic heuristic parsing fallback
    // If OPENAI_API_KEY is set, call OpenAI to extract structured fields; otherwise try regex.
    let title = body.title || 'Locum Shift';
    let location = body.location || 'Unknown';
    let rate = body.rate || null;
    let date = body.date || null;

    if (process.env.OPENAI_API_KEY && rawDescription){
      // call OpenAI
      const resp = await fetch('https://api.openai.com/v1/chat/completions', {
        method:'POST',
        headers:{ 'Authorization': 'Bearer '+process.env.OPENAI_API_KEY, 'Content-Type':'application/json' },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages: [
            { role:'system', content: 'Extract title, location, rate (number), and date (ISO) from this job posting. Respond with JSON.' },
            { role:'user', content: rawDescription }
          ],
          max_tokens: 300
        })
      });
      const j = await resp.json();
      try {
        const text = j.choices?.[0]?.message?.content;
        const parsed = JSON.parse(text);
        title = parsed.title || title;
        location = parsed.location || location;
        rate = parsed.rate || rate;
        date = parsed.date || date;
      } catch(e){
        // ignore parse error, fallback to heuristics
        console.error('OpenAI parse error', e);
      }
    } else {
      // heuristic: try find $xx or number/hr
      const m = rawDescription.match(/\$?([0-9]{2,4})\/?hr/);
      if (m) rate = parseFloat(m[1]);
      const loc = rawDescription.match(/in\s+([A-Za-z\s,]+)/);
      if (loc) location = loc[1].trim();
    }

    const shift = await prisma.shift.create({
      data: {
        title,
        description: rawDescription,
        location,
        rate: rate ? Number(rate) : null,
        date: date ? new Date(date) : null
      }
    });
    return res.json({ success:true, shift });
  } catch(err){
    console.error(err);
    return res.status(500).json({ error: err.message });
  }
}
