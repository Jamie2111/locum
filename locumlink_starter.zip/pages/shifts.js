import prisma from '../lib/prisma'
import ShiftCard from '../components/ShiftCard'

export async function getServerSideProps(){
  const shifts = await prisma.shift.findMany({ include: { applications: true } });
  return { props: { shifts: JSON.parse(JSON.stringify(shifts)) } }
}

export default function Shifts({ shifts }){
  return (
    <main className="container">
      <h2>Available Shifts</h2>
      {shifts.length===0 && <p>No shifts yet — try POSTing to /api/ingestJob via curl or Zapier.</p>}
      <div style={{marginTop:12}}>
        {shifts.map(s=> <ShiftCard key={s.id} shift={s} />)}
      </div>
    </main>
  )
}
